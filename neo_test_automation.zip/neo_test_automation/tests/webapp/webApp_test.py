from pages.webapp.webapp_page import WebAppPage
from utilities.teststatus import TestStatus
import unittest
import pytest

@pytest.mark.usefixtures("webapp_oneTimeSetUp","setup")
class WebAppTest(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, webapp_oneTimeSetUp):
        self.ts = TestStatus(self.driver)
        self.webapppage=WebAppPage(self.driver)
        self.ts = TestStatus(self.driver)







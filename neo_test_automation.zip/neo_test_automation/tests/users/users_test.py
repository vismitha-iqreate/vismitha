from selenium import webdriver
from selenium.webdriver.common.by import By
from pages.home.login_page import LoginPage
from pages.users.user_page import UserPage
from utilities.teststatus import TestStatus
import unittest
import pytest

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class LoginTests(unittest.TestCase):


    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        self.ts=TestStatus(self.driver)
        self.userPage = UserPage(self.driver)
        self.ts = TestStatus(self.driver)

    def test_CreateValidUser(self):
        self.userPage.createValidUser()
        result=self.userPage.verifyUserCreation()
        self.ts.markFinal("check user creation" + result + "check if user is created")











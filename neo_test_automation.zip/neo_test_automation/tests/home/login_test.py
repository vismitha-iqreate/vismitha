from selenium import webdriver
from selenium.webdriver.common.by import By
from pages.home.login_page import LoginPage
from utilities.teststatus import TestStatus
import unittest
import pytest

@pytest.mark.usefixtures("oneTimeSetUp", "setUp")
class LoginTests(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self, oneTimeSetUp):
        self.loginPage = LoginPage(self.driver)
        self.ts=TestStatus(self.driver)

    @pytest.mark.run(order=3)
    def test_validLogin(self):
        self.loginPage.login("samarth@iqreateinfotech.com",123456)
        result=self.loginPage.verifyLoginSucessful()
        self.ts.markFinal("test_validlogin",result,"Login was sucessful")
        self.driver.quit()

    @pytest.mark.run(order=1)
    def test_login_without_email(self):
        self.loginPage.login("","12345")
        result=self.loginPage.verifyLoginFailedForMissingField()
        self.ts.markFinal("test login without email", result, "login should not be sucessful")
        self.driver.quit()

    @pytest.mark.run(order=2)
    def test_login_without_password(self):
        self.loginPage.login("samarth@iqreateinfotech.com","")
        result=self.loginPage.verifyLoginFailedForMissingField()
        self.ts.markFinal("test login without password",result,"login should not be sucessful")
        self.driver.quit()





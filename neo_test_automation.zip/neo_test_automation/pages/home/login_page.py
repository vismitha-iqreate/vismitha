from selenium.webdriver.common.by import By
from selenium import webdriver
import logging
import utilities.custom_logger as cl
from base.custom_selenium_driver import SeleniumDriver
from base.basepage import BasePage
class LoginPage(BasePage):
    log = cl.customLogger(logging.DEBUG)
    def __init__(self,driver):
        self.driver = driver

    _email_field="email"
    _password_field="password"
    _login_button="//button"

    # Defining actions for each element

    def enterEmail(self,email):
        self.sendKeys(email,self._email_field)

    def enterPassword(self,password):
        self.sendKeys(password,self._password_field)

    def clickLoginButton(self):
        self.elementClick(self._login_button,"xpath")

    def login(self,email="",password=""):
        self.enterEmail(email)
        self.enterPassword(password)
        self.clickLoginButton()

    def verifyLoginSucessful(self):
        self.waitForElement("sidebar__toggle",locatorType="id")
        result=self.isElementPresent("sidebar__toggle")
        return result

    def verifyLoginFailedForMissingField(self):
        self.waitForElement("//strong[contains(text(),'required')]",locatorType="xpath")
        result=self.isElementPresent("//strong[contains(text(),'required')]",locatorType="xpath")
        return result









import logging
import time
import utilities.custom_logger as cl
from base.basepage import BasePage
class UserPage(BasePage):
    log = cl.customLogger(logging.DEBUG)

    def __init__(self,driver):
        self.driver=driver

    _peopleSetup="//i[@class='fa fa-users']"
    _users_tab="//a[text()='Users']"
    _createNewUser_btn="//a[contains(text(),'Create New User')]"
    _user_name="name"
    _user_email="email"
    _employee_id="employee_id"
    _save_user="//button[text()='Save']"
    _cancle_user_btn="//button[text()='Cancle']"
    _user_created_alert="//div[text()='User Created!']"

#     Define all user actions
    def clickOnPeopleSetup(self):
        self.elementClick(self._peopleSetup,"xpath")
        time.sleep(5)

    def clickOnUsersTab(self):
        self.elementClick(self._users_tab,"xpath")

    def clickOnNewUsersButton(self):
        self.elementClick(self._createNewUser_btn,"xpath")

    def typeUserName(self):
        self.sendKeys("test",self._user_name,"id")

    def typeUserEmail(self):
        self.sendKeys("test@g.com",self._user_email,"id")

    def typeEmployeeId(self):
        self.sendKeys("7633",self._employee_id,"id")

    def saveUser(self):
        self.elementClick(self._save_user,"xpath")

    def createValidUser(self):
        self.clickOnPeopleSetup()
        self.clickOnUsersTab()
        self.clickOnNewUsersButton()
        self.typeUserName()
        self.typeUserEmail()
        self.typeEmployeeId()

    def verifyUserCreation(self):

        result=self.isElementPresent(self._user_created_alert,"xpath")
        return result











import logging
import time
import utilities.custom_logger as cl
from base.basepage import BasePage

class WebAppPage(BasePage):
    log = cl.customLogger(logging.DEBUG)


    def __init__(self,driver):
        self.driver = driver

    _email="email"
    _password="password"
    _signin_btn="//button"
    _upload_btn="//span[text()='Upload']"




    def typeEmail(self,email):
        self.sendKeys(email,self._email)

    def typePassword(self,password):
        self.sendKeys(password,self._password)

    def clickSignInBtn(self):
        self.elementClick(self._signin_btn,"xpath")

    def webAppLogin(self,un="",pwd=""):
        self.typeEmail(un)
        self.typePassword(pwd)
        self.clickSignInBtn()














